package apassignment22f23365server;
import java.net.*;
import java.io.*;
import java.sql.*;
// I created a thread class for server
class ServerThread implements Runnable
{
    public void run()
    {
        try
        {
            // I Created a server socket to connect to the client with the port number given on the client.
            ServerSocket ss= new ServerSocket(9367);
            Socket s = ss.accept();
            //Input and output streams are used for communication with the client.
            DataOutputStream dos = new DataOutputStream(s.getOutputStream());
            // I Received the result from the client by using the codes below.
            DataInputStream dis = new DataInputStream(s.getInputStream());
            int civil_no = dis.readInt();
            int option = dis.readInt();
            // Depends on the option given by the user from client, the booking duration is different, I used an if statement to make calculations easier. 
            double ticketp = 50.0;
            int bookingduration = 0;
            
            if(option ==1){
                bookingduration = 30;
            }
            else if(option ==2){
                bookingduration = 180;
            }
            else if(option == 3){
                bookingduration = 365;
            }
            else {
            }
        
             // Connect to the database I created with the username and password.
            String host = "jdbc:derby://localhost:1527/BookingMwasalat";
            String username = "Furqan";
            String password = "qwert";
            
            Connection con = DriverManager.getConnection(host, username, password);
            //I received the appropriate data from the database.
            String query = "select * from BOOKINGMWASALAT where \"OPTION\" =" +option;
            
            Statement stmt = con.createStatement();
            stmt.execute(query);
            ResultSet rs = stmt.getResultSet();
            
            if (rs.next())
            {
                String booking_duration = rs.getString("BOOKINGDURATION");
                double discount = rs.getDouble("DISCOUNT");
              // this will calculate the cost price, discounted price, and final price
                double cp = ticketp * bookingduration;
                discount *= cp;
                double fp = cp - discount;
                // This will send all the values from user to the client.
                dos.writeDouble(cp);
                dos.writeDouble(discount);
                dos.writeDouble(fp);
                // I closed the connection.
                dos.close();
                s.close();
                ss.close();
                
            }
            
        }
        // incase there is any errors in the codes, this will catch the errors.
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}


public class APAssignment22F23365Server {

    public static void main(String[] args) {
        // This is the main thread by creating an object for running the child class.
        ServerThread st = new ServerThread();
        Thread t = new Thread(st);
        t.start();
        
    }
}
