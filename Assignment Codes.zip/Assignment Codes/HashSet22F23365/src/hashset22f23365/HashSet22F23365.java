package hashset22f23365;
import java.util.HashSet;
import java.util.Set;

public class HashSet22F23365 {
    public static void main(String[] args) {
        HashSet<String> hs = new HashSet<>();

        // Adding the elements
        hs.add("GMC");
        hs.add("Mercedes");
        hs.add("BMW");

        System.out.println(hs);
        
            hs.remove("BMW");
            System.out.println("After removing the element" +hs);
            hs.remove("GMC");
            System.out.println("After removing the element" +hs);
        }
    }