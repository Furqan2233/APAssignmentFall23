package apassignment22f23365client;
import java.net.*;
import java.io.*;
import java.util.Scanner;

// I created a thread class for client
class ClientThread implements Runnable
{
    public void run()
    {
              
        try
        {
            // I Created a socket to connect to the server with the port number.
            Socket s = new Socket("localhost", 9367);
            // Scanner is used to allow users to input data.
            Scanner sc = new Scanner(System.in);
            
            //Input and output streams are used for communication with the server.
            DataOutputStream dos = new DataOutputStream(s.getOutputStream());
             // Accept the civil number input from user.
            System.out.print("Enter Civil Number: ");
            int civil_no = sc.nextInt();
            
            boolean abc = false;
            int option = 0;
            //I used a while loop for the option until the criteria is met given from a user, what it will do is when the user inputs a wrong number in this case, certain block of code is repeated infinite amount of times.
            while(!abc)
                
            {
                System.out.println("Below Select the Booking Plan by entering Option number from 1-3: \n 1: Monthly \n 2: Half Yearly \n 3: Yearly \n  ");
                option = sc.nextInt();
                switch(option)
                {
                    case 1:
                    {
                        abc = true;
                        break;
                    }
                    case 2:
                    {
                        abc = true;
                        break; 
                    }
                    case 3: 
                    {
                        abc = true;
                        break; 
                    }
                    default:
                        System.out.println("Invalid option given(not 1,2,3), Try Again Please.");
                        // this will restart the operation unlimited times
                        continue;
                }
            }
            
            // This will send all the values from user to the server.
            dos.writeInt(civil_no);
            dos.writeInt(option);
            dos.flush();
            
             // I Received the result from the server by using the codes below.
            DataInputStream dis = new DataInputStream(s.getInputStream());
            double cp = dis.readDouble();
            double discount = dis.readDouble();
            double fp = dis.readDouble();
            // I used the below codes to display the results in the screen.
            System.out.println("The Calculated Price: "+ cp);
            System.out.println("The Discount given: "+ discount);
            System.out.println("The Final Price: "+ fp);
            // I closed the connection.
            dos.close();
            s.close();
            
        }
        // incase there is any errors in the codes, this will catch the errors. 
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

}

public class APAssignment22F23365Client {

    
    public static void main(String[] args) {
        // This is the main thread by creating an object for running the child class.
        ClientThread ct = new ClientThread();
        Thread t = new Thread(ct);
        t.start(); 
        
    }
    
}

