package treeset22f23365;
import java.util.TreeSet;
import java.util.Set;

public class TreeSet22F23365 {
    public static void main(String[] args) {
        // Creating a TreeSet
        TreeSet<String> ts = new TreeSet<>();

        // Adding the elements
        ts.add("Amber");
        ts.add("Blue");
        ts.add("Green");
        ts.add("Red");
        
        System.out.println(ts);
        
        ts.remove("Amber");
        System.out.println("After removing the element" +ts);
        
        ts.remove("Red");
        System.out.println("After removing the element" +ts);
    }
}
